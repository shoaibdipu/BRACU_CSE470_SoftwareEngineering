package com.dineout.code.model.reporting.EmailSender;/*
public class TableRow {
    Object[] cells;

    public TableRow(Object[] cells) {
        this.cells = cells;
    }

}
*/
