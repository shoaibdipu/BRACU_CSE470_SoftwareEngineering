package com.dineout.code.model.kitchen.models;

public class Dish {
}
